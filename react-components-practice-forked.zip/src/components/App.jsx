import React from "react";
import Heading from "./Heading.jsx";

function App() {
  return <Heading />;
}

export default App;
