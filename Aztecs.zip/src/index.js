//Create a react app from scratch.
import React from "react";
import ReactDOM from "react-dom";
//It should display a h1 heading.

ReactDOM.render(
  <div>
    <h1>Homo Deus</h1>
    <ul>
      <li>There is no justice in history</li>
      <li>As bad as the present seem to be, the past is way worse </li>
      <li>
        Life on other planet is something to look forward to because humanity
        will be able to truly plan its course and not just make things up as it
        goes along
      </li>
    </ul>
  </div>,
  document.getElementById("root")
);
//It should display an unordered list (bullet points).
//It should contain 3 list elements.
